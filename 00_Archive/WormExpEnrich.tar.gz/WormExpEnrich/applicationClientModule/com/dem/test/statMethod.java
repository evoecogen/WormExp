package com.dem.test;

public class statMethod {

	public double fisherTest(){
		double p=1;
		return p;
	}
}
