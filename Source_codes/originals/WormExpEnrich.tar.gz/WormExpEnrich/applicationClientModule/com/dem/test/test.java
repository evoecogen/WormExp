package com.dem.test;


import org.apache.commons.math3.distribution.HypergeometricDistribution;


public class test {

	public static void main(String[] args)
    {
      /*ContingencyTable2x2[] arrayOfContingencyTable2x2 = new ContingencyTable2x2[i];
      arrayOfContingencyTable2x2[0] = new ContingencyTable2x2(3, 1, 1, 3);
      arrayOfContingencyTable2x2[1] = new ContingencyTable2x2(8, 2, 3, 5);
      arrayOfContingencyTable2x2[2] = new ContingencyTable2x2(2, 6, 18, 14);
      arrayOfContingencyTable2x2[3] = new ContingencyTable2x2(2, 3, 4, 5);
      arrayOfContingencyTable2x2[4] = new ContingencyTable2x2(8, 1, 4, 5);
      
      arrayOfContingencyTable2x2[5] = new ContingencyTable2x2(100, 210, 310, 410);
      arrayOfContingencyTable2x2[6] = new ContingencyTable2x2(200, 410, 620, 820);
      arrayOfContingencyTable2x2[7] = new ContingencyTable2x2(400, 410, 420, 420);
      arrayOfContingencyTable2x2[8] = new ContingencyTable2x2(1000, 2101, 3104, 4105);*/

    }
}
